Welcome to our budget app!

Developers: Seth Nowac, Sebastian Gornicki

NOTE: Default file can be found in the Text_Files folder of the trivia app root folder.